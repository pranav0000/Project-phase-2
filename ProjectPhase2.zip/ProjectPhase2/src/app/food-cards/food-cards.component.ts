import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-food-cards',
  templateUrl: './food-cards.component.html',
  styleUrls: ['./food-cards.component.css']
})
export class FoodCardsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
