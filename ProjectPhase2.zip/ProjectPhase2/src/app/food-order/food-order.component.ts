import { Component, OnInit } from '@angular/core';
import {ApiService} from '../shared/api.service';
import {food_list} from '../food_list.model'


@Component({
  selector: 'app-food-order',
  templateUrl: './food-order.component.html',
  styleUrls: ['./food-order.component.css']
})
export class FoodOrderComponent implements OnInit {
  foodData: any;
 

  fn?:string ;
  pr?:number;
  array =[] as  any; // now we can  push json objects
  total_bill:number=0;
  customer_name:string="";
  

  
  
  
  
  
  
  
  

  constructor( private api : ApiService) {}
  ngOnInit(): void {
    this.getFoodData();
  }

  getFoodData(){
    this.api.getFood().subscribe(res=> { this.foodData= res})
  }


  FoodCart(fname:string,price:number){
    this.pr=0;
    this.fn="";
   
    this.fn= fname;
    this.pr=price;
    this.array.push({"fname":this.fn, "price":this.pr});

    //  for(let i in this.array)
     this.total_bill+=Number(this.pr);
    }

}

// 1. getting data from food-order.comp.html --> food-order.comp.ts
// 2. [{ "foodname":"name1", "price":price1 },  { "foodname":"name2", "price":price2 },  { "foodname":"name3", "price":price3 }]
// 3. food_order.comp.html --> ngfor --> populate table