import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fried-rice',
  templateUrl: './fried-rice.component.html',
  styleUrls: ['./fried-rice.component.css']
})
export class FriedRiceComponent implements OnInit {
  people?:any[];
  x:any={};
  msg:string='';
  constructor() { 
    this.people=[
      {"id":1001,"pname":"Arvind","gender":"Male","age":22},
      {"id":1002,"pname":"Navya","gender":"Female","age":20},
      {"id":1003,"pname":"Raghu","gender":"Male","age":17},
      {"id":1004,"pname":"Radhe","gender":"Female","age":25}
    ];
  }

  getpersonbyID(id:number){
    //Cloning the object
    this.x=JSON.parse( JSON.stringify( this.people?.find(x=>x.id==id)));
  }
  deletpersonbyID(id:number){
    if(confirm('Are you Sure..?'))
    {
      var i =this.people?.find(x=>x.id==id);
      this.people?.splice(i,1);
      this.msg=`Count of People ${this.people?.length}`;
    }

  }
  addperson(){
    this.people?.push(this.x)
    this.msg=`Count of People ${this.people?.length}`;
  }
  editpersonbyID(id:number){
      var i =this.people?.find(x=>x.id==id);
      this.people?.splice(i,1,this.x);
  }

  

  ngOnInit(): void {
  }

}
